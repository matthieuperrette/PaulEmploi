

function test(){
    console.log("hello !")

}